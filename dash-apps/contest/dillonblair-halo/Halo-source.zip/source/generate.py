from pathlib import Path
from math import sin,cos,pi,exp
from xml.sax.saxutils import escape
root=Path(__file__).resolve().parent
seq=100;layers=[];props=[];vals=[];lookup={}
SURFACES = {}

def uid():
 global seq
 seq+=1;return f'0:{seq}'
def prop(name,value=0,typ='Number'):
 if name in lookup:return lookup[name]
 p=uid();lookup[name]=p;props.append(f'<ViewModelProperty{typ} name="{name}" id="{p}"/>');vals.append(f'<ViewModelInstance{typ} viewModelPropertyId="{p}" propertyValue="{escape(str(value))}"/>');return p
def bind(p,k):return f'<DataBindContext sourcePathIds="0:40-{p}" propertyKey="{k}"/>'
def color(c):return c if len(c)==8 else 'FF'+c
class NumberRef(float):
 def __new__(cls,value,key):
  obj=float.__new__(cls,value);obj.key=key;return obj
class ColorRef(str):
 def __new__(cls,value,key):
  obj=str.__new__(cls,value);obj.key=key;return obj
def colorBind(c,key):return bind(prop(c.key,str(c),'Color'),key) if isinstance(c,ColorRef) else ''
def surface(c):
 if not isinstance(c,ColorRef) and c in SURFACES:
  return ColorRef(color(c),SURFACES[c][0])
 return c
def paint(c=None,grad=None):
 if grad:
  typ,coords,stops=grad
  xml=f'<{typ} startX="{coords[0]}" startY="{coords[1]}" endX="{coords[2]}" endY="{coords[3]}">'
  for pos,c in stops:
   c=surface(c)
   xml+=f'<GradientStop position="{pos}" colorValue="{color(c)}">'+colorBind(c,38)+'</GradientStop>'
  return xml+f'</{typ}>'
 c=surface(c)
 return f'<SolidColor colorValue="{color(c)}">'+colorBind(c,37)+'</SolidColor>'
def shape(x,y,geo,c=None,grad=None,stroke=None,sw=1,opacity=None,rotation=0):
 xml=f'<Shape x="{x:.3f}" y="{y:.3f}" rotation="{rotation:.6f}">{bind(opacity,18) if opacity else ""}'+geo
 if c or grad:xml+='<Fill>'+paint(c,grad)+'</Fill>'
 if stroke:xml+=f'<Stroke thickness="{sw}">'+(bind(prop(sw.key,float(sw)),47) if isinstance(sw,NumberRef) else '')+paint(stroke)+'</Stroke>'
 layers.append(xml+'</Shape>')
def rect(x,y,w,h,c=None,r=0,grad=None,stroke=None,sw=1,p=None):shape(x,y,f'<Rectangle width="{w}" height="{h}" cornerRadiusTL="{r}"/>',c,grad,stroke,sw,p)
def ellipse(x,y,w,h,c=None,grad=None,stroke=None,sw=1,p=None):shape(x,y,f'<Ellipse width="{w}" height="{h}"/>',c,grad,stroke,sw,p)
def poly(points,c,p=None,grad=None,stroke=None,sw=1):shape(0,0,'<PointsPath isClosed="true">'+''.join(f'<StraightVertex x="{x:.3f}" y="{y:.3f}" radius="3"/>' for x,y in points)+'</PointsPath>',c,grad,stroke,sw,p)
def path(points,c,sw=1,p=None):shape(0,0,'<PointsPath>'+''.join(f'<StraightVertex x="{x:.3f}" y="{y:.3f}"/>' for x,y in points)+'</PointsPath>',stroke=c,sw=sw,opacity=p)
def text(t,x,y,size,c='EDE7DA',name=None,font=30,spacing=0):
 st=uid();p=prop(name,t,'String') if name else None
 layers.append(f'<Text x="{x}" y="{y}" originX="0.5" originY="0.5" sizingValue="autoWidth"><TextStylePaint id="{st}" fontAssetId="0:{font}" fontSize="{size}" letterSpacing="{spacing}"><Fill>{paint(c)}</Fill></TextStylePaint><TextValueRun styleId="{st}" text="{escape(t)}">{bind(p,268) if p else ""}</TextValueRun></Text>')
def readout(t,suffix,x,y,size,name,suffixname):
 a,b=uid(),uid()
 layers.append(f'<Text x="{x}" y="{y}" originX="0.5" originY="0.5" sizingValue="autoWidth"><TextStylePaint id="{a}" fontAssetId="0:30" fontSize="{size}"><Fill>{paint(ColorRef("FFF7F8F1","themeDigits"))}</Fill></TextStylePaint><TextStylePaint id="{b}" fontAssetId="0:31" fontSize="18"><Fill>{paint("A5B2B7")}</Fill></TextStylePaint><TextValueRun styleId="{a}" text="{t}">{bind(prop(name,t,"String"),268)}</TextValueRun><TextValueRun styleId="{b}" text="{suffix}">{bind(prop(suffixname,suffix,"String"),268)}</TextValueRun></Text>')
def group(start,name,value=0,dy=0):
 fragment=layers[start:];del layers[start:]
 layers.append('<Node y="'+str(dy)+'" name="'+name+'">'+bind(prop(name,value),18)+''.join(reversed(fragment))+'</Node>')
def linear(stops,x1=0,y1=-100,x2=0,y2=100):return ('LinearGradient',(x1,y1,x2,y2),stops)
def radial(stops,r=100,x=0,y=0):return ('RadialGradient',(x,y,x+r,y),stops)
def arc(cx,cy,r,a0,a1,c,sw=1,p=None):path([(cx+cos((a0+(a1-a0)*i/120)*pi/180)*r,cy+sin((a0+(a1-a0)*i/120)*pi/180)*r) for i in range(121)],c,sw,p)

# Materials are embedded pixels; every reading and illuminated segment is native.
W,H=1440,600
# Neutral first-frame values, before the first controller/telemetry advance.
for name,value in [('speed','0'),('battery','—'),('batteryUnit',''),('packTemp','—'),('packTempUnit',''),('limit','—'),('odo','—'),('gearText','—'),('clock','--:--')]:prop(name,value,'String')
layers.append('<Image x="923" y="426" assetId="0:60">'+bind(prop('startupFace',0.45),18)+'</Image>')
white='F6F8FB'
def sweep(t,outer=1):
 a=(148-86*t)*pi/180
 return (922+cos(a)*(818+57*outer),935-sin(a)*(764+53*outer))
def glowPath(points,col,width,strength):
 # Layered alpha falloff stays consistent across the native mobile renderers.
 rgb=col[-6:]; peak=int(col[:2],16)/255 if len(col)==8 else .5
 combined=0.0
 for w in range(int(width+strength*4),int(width),-2):
  target=peak*exp(-.5*((w/2)/(strength*.62))**2)
  alpha=max(0,min(255,round((target-combined)/(1-combined)*255)))
  if alpha:
   path(points,f'{alpha:02X}'+rgb,w)
   combined+=alpha/255*(1-combined)
# A shader-rendered glass/metal insert replaces the flat concentric center face.
# It is behind all live readings, with the existing material plate beneath it.
layers.append('<Shape x="920" y="450" id="0:84" name="Center glass material clip"><Ellipse width="770" height="350"/></Shape>')
layers.append('<Image x="920" y="450" scaleX="0.5" scaleY="0.5" assetId="0:61" name="Shader rendered recessed glass">'+bind(prop('startupFace',0.45),18)+'<ClippingShape sourceId="0:84"/></Image>')
# Recessed luminous ceramic segments, fitted to the material channel.
for i in range(126):
 t=(i+.5)/126;t0=(i+.17)/126;t1=(i+.83)/126
 pts=[sweep(t0,0),sweep(t0,1),sweep(t1,1),sweep(t1,0)]
 # Fixed warm progression: amber at 7, coral-red at 8, full red at 9.
 if t>=7/9:
  position=t*9
  a,b,u=((255,194,87),(255,105,67),position-7) if position<8 else ((255,105,67),(255,73,63),position-8)
  c=''.join(f'{round(x+(y-x)*u):02X}' for x,y in zip(a,b))
  shade='FF'+''.join(f'{round(int(c[j:j+2],16)*.55):02X}' for j in (0,2,4))
 else:
  c=ColorRef('FFE5F2FC','accent0');shade=ColorRef('FFA0A9B0','dark0')
 poly(pts,'14202A',stroke='25333D',sw=.7)
 if t>=7/9:poly(pts,'28'+c)
 poly(pts,None,prop('arc'+str(i)),linear([(0,shade),(.42,c),(1,c)],pts[0][0],pts[0][1],pts[1][0],pts[1][1]),stroke='36D8EFFF',sw=.6)
 poly(pts,'FAFFFFFF',prop('tip'+str(i)))
for j in range(37):
 t=j/36;a=(148-86*t)*pi/180;major=j%4==0
 p1=(922+cos(a)*803,935-sin(a)*750)
 p2=(922+cos(a)*(776 if major else 789),935-sin(a)*(725 if major else 737))
 path([p1,p2],'F0F7FF' if major else '658499',3 if major else 1.2)
 if major:text(str(j//4),922+cos(a)*730,935-sin(a)*700,55,'E8F2FF')
prop('scaleLabel','','String')
# White speed, with a fine blue edge in an active assistance state.
start=len(layers)
# Native glyph layers create a soft blue halo around the white speed.
for radius,col in [(10,'0A48AFFF'),(7,'1248AFFF'),(4,'2348AFFF'),(2,'5048AFFF')]:
 for j in range(8):
  a=2*pi*j/8;text('57',920+cos(a)*radius,449+sin(a)*radius,198,col,'speed')
for dx,dy in [(-1.4,0),(1.4,0),(0,-1.4),(0,1.4)]:text('57',920+dx,449+dy,198,'46AAFF','speed')
group(start,'assistOn')
text('57',920,449,198,'FFFFFF','speed');text('mph',920,574,42,'B8C9D6','unit')
# Directional green light follows the recessed center glass instead of arrows.
for side,a0,a1 in [('left',122,238),('right',-58,58)]:
 points=[(920+350*cos((a0+(a1-a0)*i/90)*pi/180),450+151*sin((a0+(a1-a0)*i/90)*pi/180)) for i in range(91)]
 start=len(layers)
 glowPath(points,'A54CE88B',5,14)
 path(points,'65F0A0',4)
 path(points,'D2FFE1',1)
 group(start,side)
# Native segments and values inside the original secondary housings.
def smallAt(x,y,t,k=1):
 a=(180-180*t)*pi/180
 return (x+cos(a)*105*k,y-sin(a)*84*k)
def smallGauge(x,y,key,thermal=False):
 for i in range(32):
  t=(i+.5)/32;t0=(i+.16)/32;t1=(i+.84)/32
  pts=[smallAt(x,y,t0,.84),smallAt(x,y,t0),smallAt(x,y,t1),smallAt(x,y,t1,.84)]
  poly(pts,'202D38',stroke='34434D',sw=.6)
  c=('85D7FF' if i<5 else 'FF6B60' if i>=28 else 'E9F5FF') if thermal else ColorRef('FFEDF7FF','batteryArcColor')
  poly(pts,None,prop(key+str(i)),linear([(0,'FF8EA8BC'),(.5,'FFFFFFFF'),(1,c)],x,y-10,x,y-80),stroke='70DBEFFF',sw=.6)
 path([smallAt(x,y,i/80,.76) for i in range(81)],'547087',1)
 for t in [0,.5,1]:path([smallAt(x,y,t,.76),smallAt(x,y,t,.70)],'A9C5D8',1.2)
smallGauge(1470,418,'tempArc',True)
readout('82',' °F',1470,396,49,'packTemp','packTempUnit')
text('C',1370,435,23,'63CDFF');text('H',1568,435,23,'FF746D')
text('PACK TEMP',1470,452,18,'90B5CE',font=31,spacing=2)
start=len(layers)
smallGauge(1470,590,'batteryArc')
readout('76','%',1470,568,49,'battery','batteryUnit')
text('E',1370,605,23,'FF746D');text('F',1568,605,23,'EAF7FF')
text('BATTERY',1470,621,18,'90B5CE',font=31,spacing=2)
group(start,'batteryGaugeOn',1)
# A single aligned lower information row keeps the clock out of the speed housing.
readout('0','%',370,683,42,'powerReadout','powerUnit')
text('POWER',370,717,17,'90B5CE',font=31,spacing=2)
# Latest completed 0-60 result, a quiet green column just left of the clock.
start=len(layers)
text('—',510,685,30,'62ED92','launchLast',31)
text('0-60 MPH',510,717,15,'92BCAC',font=31,spacing=.5)
group(start,'launchOn')
start=len(layers)
text('11:09',650,685,28,'EDF4FF','clock')
text('TIME',650,717,15,'90B5CE',font=31,spacing=2)
text('26099 mi',920,685,30,'EDF4FF','odo')
text('ODO',920,717,15,'90B5CE',font=31,spacing=2)
text('—',1095,685,28,'EDF4FF','trip')
text('TRIP',1095,717,15,'90B5CE',font=31,spacing=2)
group(start,'clockOn',1)
text('D',1467,688,55,'EDF4FF','gearText')
# Quiet, readable sign, no distracting large overspeed flash.
signStart=len(layers)
start=len(layers)
rect(0,0,94,126,None,r=11,stroke='FF453F',sw=4)
group(start,'limitOutline')
start=len(layers)
glowPath([(-43,-59),(43,-59),(43,59),(-43,59),(-43,-59)],'ADFF4540',5,12)
group(start,'limitGlow')
rect(0,0,86,118,'F4F3EB',r=8,stroke='A1A79F',sw=2)
rect(0,0,78,110,None,r=6,stroke='1B2020',sw=2)
text('SPEED',0,-38,13,'151919',font=31,spacing=1)
text('LIMIT',0,-22,13,'151919',font=31,spacing=1)
text('50',0,17,42,'111616','limit',31);text('mph',0,45,10,'202626','limitUnit',31)
fragment=layers[signStart:];del layers[signStart:];p=prop('limitScale',1)
layers.append('<Node name="Speed limit" x="1260" y="649">'+bind(p,16)+bind(p,17)+''.join(reversed(fragment))+'</Node>')
for n in ['limitTier','limitOutlineWidth','limitRippleOn','limitRippleScale']:prop(n)
# Perimeter follows the very same machined rim. Independent warning halves.
def cubic(p0,p1,p2,p3,n=90):
 return [((1-t)**3*p0[0]+3*(1-t)**2*t*p1[0]+3*(1-t)*t*t*p2[0]+t**3*p3[0],(1-t)**3*p0[1]+3*(1-t)**2*t*p1[1]+3*(1-t)*t*t*p2[1]+t**3*p3[1]) for t in [i/n for i in range(n+1)]]
lcurve=cubic((92,470),(300,155),(646,60),(922,60))
rhalf=[(1844-x,y) for x,y in reversed(lcurve)]
rim=[(137,755),(88,708)]+lcurve+rhalf[1:]+[(1740,708),(1690,755),(137,755)]
start=len(layers)
glowPath(rim,'782081FF',6,12);path(rim,'FF238EFF',3);path(rim,'FFD1EDFF',1)
group(start,'assistOn')
for side,coords in [('Left',[(137,755),(88,708)]+lcurve[:-2]),('Right',[(1690,755),(1740,708)]+list(reversed(rhalf[2:])) )]:
 start=len(layers)
 glowPath(coords,'ADFF302C',9,28);glowPath(coords,'CCFF302C',7,13);path(coords,'FF564C',5);path(coords,'FFE7D9',1.2)
 group(start,'blind'+side+'On')
start=len(layers);glowPath(rim,'A055F5A0',6,18);path(rim,'7EFFBB',2);group(start,'greenNudge')
prop('assist','','String');prop('manualOn');prop('status','','String');prop('date','','String')
# Keep diagnostics in the view model; no tiny orange footer is rendered.
prop('warning','','String')
# Fit the exact reference framing to the original responsive coordinate space.
layers=['<Node name="Photoreal instruments" scaleX="'+str(1440/1846)+'" scaleY="'+str(600/852)+'">'+bind(prop('instrumentScaleY',600/852),17)+bind(prop('instrumentOffsetY',0),14)+''.join(reversed(layers))+'</Node>']
instrumentContent=layers.pop()

# Compact modal with large, explicit touch targets.
start=len(layers)
rect(720,300,4000,2400,'DD020609')
rect(720,300,810,500,'101E28',r=22,stroke='526C7D',sw=1.5)
text('DISPLAY SETTINGS',550,106,25,'E5F0F4',font=31,spacing=1)
rect(1030,105,120,60,'233B4C',r=12)
text('CLOSE',1030,105,20,'D7ECF5',font=31)
rect(838,105,185,60,'233B4C',r=12);text('NOTCH LEFT',838,105,18,'D7ECF5','notchName',31)
text('COLOR',398,148,16,'86A9BD',font=31,spacing=1)
for i,(label,col) in enumerate([('PEARL','E5F2FC'),('WHITE','EAF2F3'),('YELLOW','EBF063'),('RED','FF5C4A'),('PURPLE','D68AFF'),('GREEN','62ED92')]):
 x=350+123.33*i+58
 rect(x,200,112,70,'1E3342',r=12,stroke=col,sw=1.4)
 text(label,x,201,18,ColorRef('FF'+col,'paletteLabel'+str(i)),font=31)
text('Pearl',970,148,18,'D9EDF8','themeName',31)
text('BRIGHTNESS',460,285,21,'E2EDF2',font=31)
text('100%',470,322,28,'A7DCFF','brightnessText',31)
rect(825,308,130,74,'233B4C',r=12);text('DIM',825,308,24,'D7ECF5',font=31)
rect(1000,308,180,74,'233B4C',r=12);text('BRIGHTER',1000,308,24,'D7ECF5',font=31)
rect(530,398,360,65,'1C3440',r=12)
text('GREEN NUDGE',475,398,21,'D7ECF5',font=31);text('ON',657,398,22,'79E6B2','nudgeSetting',31)
rect(910,398,360,65,'1C3440',r=12)
text('0-60 TIMER',850,398,21,'D7ECF5',font=31);text('ON',1037,398,22,'79E6B2','timerSetting',31)
rect(530,490,360,70,'1F3E55',r=12)
text('SCREEN FIT',530,490,23,'B7E1FF',font=31,spacing=.8)
rect(910,490,360,70,'1F3E55',r=12)
text('REPLAY GUIDE',910,490,23,'B7E1FF',font=31,spacing=.8)
group(start,'settingsOn')
# Separate screen-fit page keeps large controls readable and un-stretched.
start=len(layers)
rect(720,300,4000,2400,'EE020609')
rect(720,300,810,520,'101E28',r=22,stroke='526C7D',sw=1.5)
text('SCREEN FIT',490,106,26,'E5F0F4',font=31,spacing=1)
rect(1030,105,120,60,'233B4C',r=12);text('CLOSE',1030,105,20,'D7ECF5',font=31)
for i,(x,label) in enumerate([(450,'IPHONE'),(720,'DUO FOLDED'),(990,'DUO OPEN')]):
 rect(x,180,220,64,'20372F',r=10,stroke='526C61',sw=1.4)
 text(label,x,180,20,ColorRef('FF79E6B2','screenLabel'+str(i)),font=31)
text('Standard iPhone / current screen',720,236,20,'A6C3B4','fitSummary',31)
rect(720,291,740,62,'233B4C',r=10)
text('IPAD SCREEN PREVIEW',560,291,21,'D7ECF5',font=31)
text('OFF',1030,291,22,'79E6B2','previewSetting',31)
rect(530,369,360,58,'233B4C',r=10)
text('SYSTEM SIDE',453,369,18,'D7ECF5',font=31)
text('RIGHT',635,369,20,'79E6B2','systemSideName',31)
rect(910,369,360,58,'233B4C',r=10)
text('SIDE SPACE 12%',910,369,21,'D7ECF5','clearanceName',31)
rect(530,439,360,58,'233B4C',r=10)
text('HOME SPACE 8%',530,439,21,'D7ECF5','homeName',31)
rect(910,439,360,58,'233B4C',r=10)
text('RESET CLEARANCE',910,439,21,'D7ECF5',font=31)
rect(475,510,240,60,'294B3A',r=10)
text('BACK',475,510,21,'C8F4D9',font=31)
text('Tap a control to change it.',890,510,18,'A6B9B0',font=31)
group(start,'fitSettingsOn')
# Tooltips are native Rive text and graphics. They do not cover the speed.
start=len(layers)
rect(720,507,646,148,'101E2A',r=18,stroke='46647A',sw=1)
text('01 / 03',444,450,10,'7AA7C8','guideStep',31,spacing=1.3)
text('SWIPE TO CHANGE COLOR',720,475,18,'E4F2F8','guideTitle',31,spacing=.8)
text('Swipe left or right to choose a new palette.',720,507,16,'97B5CA','guideBody',31)
text('SKIP',446,558,12,'7F9CAE',font=31)
text('NEXT',985,558,12,'AEDCFF','guideNext',31)
for x in [704,720,736]:ellipse(x,558,4,4,'4D7390')
group(start,'guideOn')
# Palette and brightness changes are visible directly; no small toast overlays.
prop('feedbackOn',0);prop('feedbackText','','String')
# Native inputs match DashPilot's declared property types and names.
for name,value in [('currentTime',0),('egoSpeed',0),('gear',0),('leftBlinker',0),('rightBlinker',0),('leftBlindSpot',0),('rightBlindSpot',0),('fusedSpeedLimit',0),('accSetSpeed',0),('trafficLightColor',0),('stopLineDist',0),('powerLevel',0),('maxRegenPower',0),('maxDischargePower',0),('nominalEnergyRemaining',0),('fullPackEnergy',0),('energyBuffer',0),('odometer',0),('anyDoorOpen',0),('buckleStatus',0),('packTMin',0),('packTMax',0)]:prop(name,value)
for name,value in [('isImperial','true'),('adasOn','false'),('showCarBattery','true'),('showOdometer','true'),('alwaysOnBlindSpotMonitor','true'),('darkMode','true'),('fsdActive','false'),('nudgeEnabled','true'),('timerEnabled','true'),('guideCompleted','true')]:prop(name,value,'Boolean')
prop('batteryKnown','false','Boolean');prop('packTempKnown','false','Boolean');prop('packTempLevel',0)
prop('dataSourceType','','String')
for name,value in [('layoutScale',1),('layoutX',0),('layoutY',0),('themeIndex',5)]:prop(name,value)
prop('notchSide',0)
prop('screenProfile',0);prop('systemSide',1);prop('sideClearance',12);prop('homeClearance',8)
prop('duoPreview','false','Boolean')
prop('brightness',1)
rect(.5,.5,1,1,'000000',p=prop('dimOpacity',0))
dimmer='<Node name="Screen dimmer">'+bind(prop('viewportWidth',2160),16)+bind(prop('viewportHeight',1080),17)+layers.pop()+'</Node>'
frame='<Node name="ResponsiveFrame">'+bind(lookup['layoutX'],13)+bind(lookup['layoutY'],14)+bind(lookup['layoutScale'],16)+bind(lookup['layoutScale'],17)+instrumentContent+'</Node>'
ui='<Node name="Readable settings">'+bind(prop('uiX',0),13)+bind(prop('uiY',0),14)+bind(prop('uiScale',1),16)+bind(prop('uiScale',1),17)+''.join(reversed(layers))+'</Node>'
decor=[]
for prefix in ['previewRail','previewHome']:
 rect(.5,.5,1,1,'18231E')
 decor.append('<Node>'+bind(prop(prefix+'X',0),13)+bind(prop(prefix+'Y',0),14)+bind(prop(prefix+'Width',0),16)+bind(prop(prefix+'Height',0),17)+layers.pop()+'</Node>')
previewDecor='<Node name="Simulated reserved space">'+bind(prop('previewOn',0),18)+''.join(decor)+'</Node>'
for n in ['safeX','safeY','safeWidth','safeHeight','panelX','panelY','panelWidth','panelHeight']:prop(n)

driver='<LayoutComponent width="2160" height="1080" styleId="0:51" name="Screen" id="0:50"><LayoutComponentStyle layoutWidthScaleType="fill" layoutHeightScaleType="fill" widthUnitsValue="auto" heightUnitsValue="auto" id="0:51"/><Fill>'+paint('020405')+'</Fill><ScriptedLayout name="Native controller" scriptAssetId="0:80"/></LayoutComponent>'
scene='<Rive version="1" kind="fragment"><Artboard id="0:2" name="Halo" width="2160" height="1080" viewModelId="0:40" defaultStateMachineId="0:7" styleId="0:5"><LayoutComponentStyle id="0:5"/>'+dimmer+ui+previewDecor+frame+driver+'<StateMachine id="0:7" name="Cluster"><StateMachineLayer><EntryState/></StateMachineLayer></StateMachine></Artboard><ImageAsset file="plate.png" id="0:60" name="Embedded material face"/><ImageAsset file="center-depth.png" id="0:61" name="Shader rendered glass and machined bevel"/><FontAsset file="Cluster.ttf" id="0:30" name="Michroma"/><FontAsset file="Body.ttf" id="0:31" name="Barlow"/><ScriptAsset file="logic.luau" name="logic" isModule="true" id="0:81"/><ScriptAsset file="controller.luau" name="controller" id="0:80"/><ViewModel id="0:40" name="DashViewModel" defaultInstanceId="0:41">'+''.join(props)+'<ViewModelInstance id="0:41" name="Default" exports="true">'+''.join(vals)+'</ViewModelInstance></ViewModel></Rive>'
(root/'scene.rml').write_text(scene);(root/'rive.yaml').write_text('name: halo-duo\nmain: Halo\nartboard:\n  background: "#020405"\n')
