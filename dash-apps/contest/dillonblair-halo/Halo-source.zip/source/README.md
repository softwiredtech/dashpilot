# Halo source

Rive CLI project for the submitted Halo.riv. Main artboard Halo, default state machine Cluster, default DashViewModel instance. All visual and font assets are embedded.

## Rebuild

Use Rive CLI 1.8.0 or a compatible later version:

```sh
python3 generate.py
rive . --verify
rive inspect . --summary
rive . --test
```

For a native capture use `rive . --screenshot --advance=120`. Captures and `--once` create an unsigned export. The submitted file is signed; run `rive . --publish=local` in an authenticated Rive CLI session to sign a new distribution. Do captures/tests before the final signed export. No Rive account-project push is needed to rebuild a local file; local exports may retain Rive's watermark.

The speed arc represents vehicle speed, not RPM: 0–90 MPH or 0–180 KM/H. currentTime is seconds since local midnight. Gear 1/2/3/4 maps to P/R/N/D. adasOn is the official generic assistance-engaged flag; fsdActive is an optional extension and is not assumed to be available. Unknown sensor values render a dash where the host's defaults allow that distinction.

Touch: horizontal swipe selects the palette; vertical drag adjusts rendered dimming; hold about 650ms for Settings. Guide replay is manual. Standard iPhone/current viewport is the default. Screen Fit includes manual display profiles and optional aspect-ratio preview for an iPad. These are manual design presets, not device detection or measured operating-system safe areas. Preferences and launch results last for the session.

The material plate and center-glass material are embedded images. The optional authoring project in ../material-source renders the center-glass texture; that shader is not executed by the submitted dashboard. Native readings, progress segments and lighting overlays are driven by the controller script.

The QA launchers expect the CLI at /root/.rive/bin/rive and a Linux GLES library path; adjust these paths for your development machine. They cover native layout, telemetry changes, manual profile selection and logic cases. These local checks do not establish physical-device frame rate or compatibility.

Source and original graphics are MIT; fonts retain their included SIL OFL licenses. See ../README.md and ../licenses.
