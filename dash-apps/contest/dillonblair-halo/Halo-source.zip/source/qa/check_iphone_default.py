"""Verify fresh iPhone startup, live updates and manual entry to Duo modes."""
from pathlib import Path
import json,os,subprocess
p=Path(__file__).resolve().parents[1]
env={**os.environ,'LD_LIBRARY_PATH':'/tmp/rive-libs/usr/lib/x86_64-linux-gnu'}
def run(name,args,vp='844x390'):
    out=p/'build'/(name+'.json')
    r=subprocess.run(['/root/.rive/bin/rive',str(p),'--viewport='+vp,'--data-dump='+str(out),'--screenshot='+str(p/'build'/(name+'.png'))]+args,env=env,capture_output=True,text=True)
    assert r.returncode==0 and 'runtime error' not in (r.stdout+r.stderr).lower(),r.stdout+r.stderr
    d={x['name']:x['value'] for x in json.loads(out.read_text())['viewModel']['properties']}
    x,y,w,h=[d[k] for k in ['safeX','safeY','safeWidth','safeHeight']]
    s=d['layoutScale'];ox=d['layoutX'];oy=d['layoutY']
    assert ox+88*1440/1846*s>=x-3 and ox+1740*1440/1846*s<=x+w+3
    top=oy+60*600/852*s
    bottom=oy+(755*d['instrumentScaleY']+d['instrumentOffsetY'])*s
    assert top>=y-2 and bottom<=y+h+2
    assert d['guideOn']==0
    print('PASS',name,flush=True)
    return d
first=run('iphone-first-frame',['--advance=0'])
assert first['screenProfile']==0 and first['duoPreview'] is False and first['previewOn']==0
assert first['speed']=='0' and first['launchOn']==0
changing=['--data=gear=4','--data=buckleStatus=1','--data=egoSpeed=12','--advance=3','--data=egoSpeed=57','--data=fullPackEnergy=80','--data=nominalEnergyRemaining=60.8','--data=packTMax=82','--data=adasOn=true','--advance=120']
large=run('iphone-live-data',changing,'956x440')
assert large['screenProfile']==0 and large['speed']=='57' and large['battery']=='76'
assert large['arc78']==1 and large['arc120']==0 and large['assistOn']==1
ipad=run('ipad-standard-default',changing,'1536x1152')
assert ipad['screenProfile']==0 and ipad['previewOn']==0
def point(d,x,y):return f"{d['uiX']+d['uiScale']*x},{d['uiY']+d['uiScale']*y}"
args=['--advance=60','--pointer=down@'+point(first,720,300),'--advance=50','--pointer=up@'+point(first,720,300),'--advance=2','--pointer=click@'+point(first,530,490),'--advance=2']
menu=run('iphone-screen-fit',args)
assert menu['fitSettingsOn']==1 and menu['screenProfile']==0
args+=['--pointer=click@'+point(menu,720,180),'--advance=2']
fold=run('iphone-manual-duo',args)
assert fold['screenProfile']==1 and fold['fitSettingsOn']==1
args+=['--pointer=click@'+point(fold,720,291),'--advance=2']
preview=run('iphone-duo-preview',args)
assert preview['duoPreview'] is True and preview['previewOn']==1
assert abs(preview['panelWidth']/preview['panelHeight']-2034/1398)<.001
print('IPHONE DEFAULT ACCEPTANCE PASSED',flush=True)
