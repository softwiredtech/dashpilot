"""Native panel profiles, iPad emulation, clearance and real settings interactions."""
from pathlib import Path
import json,os,subprocess
p=Path(__file__).resolve().parents[1]
env={**os.environ,'LD_LIBRARY_PATH':'/tmp/rive-libs/usr/lib/x86_64-linux-gnu'}
base=['--data=gear=4','--data=buckleStatus=1','--data=fullPackEnergy=80','--data=nominalEnergyRemaining=60.8','--data=packTMax=82','--data=currentTime=40620','--data=odometer=9701']
launch=['--data=egoSpeed=0','--advance=45','--data=egoSpeed=1','--advance=30','--data=egoSpeed=30','--advance=120','--data=egoSpeed=60','--advance=2']
def run(name,args,vp='1536x1152'):
    out=p/'build'/(name+'.json')
    result=subprocess.run(['/root/.rive/bin/rive',str(p),'--viewport='+vp,'--data-dump='+str(out),'--screenshot='+str(p/'build'/(name+'.png'))]+base+args,env=env,capture_output=True,text=True)
    assert result.returncode==0 and 'runtime error' not in (result.stdout+result.stderr).lower(),result.stdout+result.stderr
    d={x['name']:x['value'] for x in json.loads(out.read_text())['viewModel']['properties']}
    assert d['guideOn']==0
    sx,sy,sw,sh=[d[k] for k in ['safeX','safeY','safeWidth','safeHeight']]
    scale=d['layoutScale'];ix=d['layoutX'];iy=d['layoutY']
    assert sx>=0 and sy>=0 and sw>0 and sh>0
    assert sx+sw<=d['viewportWidth']+.01 and sy+sh<=d['viewportHeight']+.01
    # Visible rim fits within each independently reserved edge.
    assert ix+88*1440/1846*scale>=sx-3
    assert ix+1740*1440/1846*scale<=sx+sw+3
    top=iy+60*600/852*scale
    bottom=iy+(755*d['instrumentScaleY']+d['instrumentOffsetY'])*scale
    assert top>=sy-2 and bottom<=sy+sh+2,(name,top,bottom,sy,sh)
    print('PASS',name,flush=True)
    return d
fold=run('duo-folded',launch+['--data=screenProfile=1'],'1017x699')
assert fold['speed']=='60' and fold['launchOn']==1 and fold['clockOn']==1
opened=run('duo-open',launch+['--data=screenProfile=2','--data=adasOn=true','--data=rightBlinker=2'],'1335x939')
assert opened['assistOn']==1 and opened['right']==1
ipad=run('ipad-folded',launch+['--data=screenProfile=1','--data=duoPreview=true'])
assert abs(ipad['panelWidth']/ipad['panelHeight']-2034/1398)<.001
ipad_open=run('ipad-open',launch+['--data=screenProfile=2','--data=duoPreview=true'])
assert abs(ipad_open['panelWidth']/ipad_open['panelHeight']-2670/1878)<.001
mirrored=run('ipad-left-side',launch+['--data=screenProfile=1','--data=duoPreview=true','--data=systemSide=0','--data=sideClearance=20','--data=homeClearance=12'])
assert mirrored['systemSideName']=='LEFT' and mirrored['safeX']>ipad['safeX']
# Use actual transformed touch positions, rather than injecting a settings flag.
def point(d,x,y):return f"{d['uiX']+d['uiScale']*x},{d['uiY']+d['uiScale']*y}"
args=['--data=screenProfile=1','--data=duoPreview=true','--advance=60','--pointer=down@'+point(ipad,720,300),'--advance=50','--pointer=up@'+point(ipad,720,300),'--advance=2','--pointer=click@'+point(ipad,530,490),'--advance=2']
menu=run('duo-settings',args)
assert menu['fitSettingsOn']==1 and menu['settingsOn']==0
args+=['--pointer=click@'+point(menu,990,180),'--advance=2']
selected=run('duo-open-selected',args)
assert selected['screenProfile']==2 and selected['fitSettingsOn']==1
args+=['--pointer=click@'+point(selected,530,369),'--advance=2']
selected=run('duo-side-selected',args)
assert selected['systemSide']==0 and selected['systemSideName']=='LEFT'
args+=['--pointer=click@'+point(selected,1030,105),'--advance=2']
closed=run('duo-settings-closed',args)
assert closed['fitSettingsOn']==0 and closed['settingsOn']==0
print('DUO ACCEPTANCE PASSED',flush=True)
