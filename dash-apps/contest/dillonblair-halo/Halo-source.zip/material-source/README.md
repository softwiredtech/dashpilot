# Halo center-material authoring source

Original WGSL/Luau material-authoring project used to render source/center-depth.png. It creates the appearance of a recessed glass face and machined metal rim. The submitted dashboard embeds the resulting image and does not run this shader per frame.

With Rive CLI 1.8.0, run `rive . --screenshot --viewport=1540x700 --fit=contain --advance=2` in this directory to render the material. Code and resulting original material asset are provided under the entry's MIT license.
