struct Controls { values: vec4<f32> };
@group(0) @binding(0) var<uniform> control: Controls;
struct VertexOutput { @builtin(position) position: vec4<f32>, @location(0) uv: vec2<f32> };
@vertex fn vs_main(@builtin(vertex_index) i:u32)->VertexOutput {
 var o:VertexOutput;
 let p=vec2<f32>(f32((i<<1u)&2u),f32(i&2u));
 o.position=vec4<f32>(p*2.0-1.0,0.0,1.0);
 o.uv=vec2<f32>(p.x,1.0-p.y);
 return o;
}
fn gauss(v:f32,w:f32)->f32 {return exp(-v*v/(w*w));}
@fragment fn fs_main(in:VertexOutput)->@location(0) vec4<f32> {
 let q=(in.uv-0.5)*2.0;
 let r=length(q);
 let coverage=1.0-smoothstep(0.985,1.0,r);
 let t=control.values.x;
 let velocity=clamp(control.values.y/100.0,0.0,1.0);
 let engaged=control.values.z;
 let drift=0.008*sin(t*0.17)*velocity;
 let l=normalize(vec3<f32>(-0.45+drift,-0.82,1.1));
 let v=vec3<f32>(0.0,0.0,1.0);
 let h=normalize(l+v);
 // A raised, curved machined chamfer; its changing normal makes a real specular rim.
 let ridge=exp(-pow((r-0.907)/0.043,2.0));
 let slope=-2.0*(r-0.907)/(0.043*0.043)*0.055*ridge;
 let n=normalize(vec3<f32>(-slope*q/max(r,0.001),1.0));
 let diffuse=max(dot(n,l),0.0);
 let specular=pow(max(dot(n,h),0.0),85.0);
 let theta=atan2(q.y,q.x);
 let turning=sin(theta*1050.0+r*11.0)*0.0045;
 let longReflection=gauss(q.y+0.22*q.x+0.40+drift,0.10)*gauss(q.x+0.20,0.85);
 let oppositeReflection=gauss(q.y+0.12*q.x-0.66,0.045)*gauss(q.x-0.20,0.55);
 var metal=vec3<f32>(0.125,0.137,0.148)*(0.40+0.80*diffuse)+vec3<f32>(specular*0.55+turning);
 metal+=vec3<f32>(0.31,0.33,0.35)*longReflection+vec3<f32>(0.24,0.26,0.28)*oppositeReflection;
 // Thick smoked glass sits below the inner lip, with contact shadow and broad reflections.
 let bowl=1.0-smoothstep(0.18,0.86,r);
 let ao=1.0-0.76*smoothstep(0.70,0.845,r);
 let hotspot=exp(-dot((q-vec2<f32>(-0.20,-0.35))*vec2<f32>(1.0,1.6),(q-vec2<f32>(-0.20,-0.35))*vec2<f32>(1.0,1.6))*2.7);
 let glassReflect=gauss(q.y+0.18*q.x+0.44+drift,0.105)*gauss(q.x+0.25,0.70);
 var glass=(vec3<f32>(0.015,0.020,0.025)+vec3<f32>(0.025,0.030,0.034)*bowl+vec3<f32>(0.075,0.082,0.089)*hotspot)*ao;
 glass+=vec3<f32>(0.080,0.090,0.098)*glassReflect;
 let fresnel=pow(clamp(r/0.84,0.0,1.0),9.0);
 glass+=vec3<f32>(0.009,0.012,0.015)*fresnel;
 glass+=vec3<f32>(0.004,0.016,0.031)*gauss(r-0.805,0.022)*engaged;
 let materialMix=smoothstep(0.841,0.852,r);
 var col=mix(glass,metal,materialMix);
 // Thin polished lips terminate the chamfer; the shadows establish its thickness.
 col+=vec3<f32>(0.12,0.13,0.14)*gauss(r-0.858,0.003)*(0.2+max(-q.y,0.0));
 col*=1.0-0.65*gauss(r-0.979,0.014);
 col+=vec3<f32>(0.09,0.10,0.11)*gauss(r-0.967,0.003)*max(-q.y,0.0);
 return vec4<f32>(clamp(col,vec3<f32>(0.0),vec3<f32>(1.0))*coverage,coverage);
}
